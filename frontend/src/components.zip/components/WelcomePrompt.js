import React, { useEffect, useState, useContext } from "react";
import { useNavigate } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";
import "./cookieconsent.css";

export default function WelcomePrompt() {
  const [show, setShow] = useState(false);
  const navigate = useNavigate();
  const { isLoggedIn } = useContext(AuthContext);

  useEffect(() => {
    const cookieConsent = localStorage.getItem("cookieConsent");
    if (!cookieConsent && !isLoggedIn) {
      setShow(true);
    }
  }, [isLoggedIn]);

  const handleAccept = () => {
    localStorage.setItem("cookieConsent", "true");
    setShow(false);
  };

  if (!show) return null;

  return (
    <div className="cookie-popup">
      <p>
        🍪 This website uses cookies to enhance your experience. Please log in or register to access all features.
      </p>
      <div className="btn-group">
        <button className="login" onClick={() => { handleAccept(); navigate("/login"); }}>
          Login
        </button>
        <button className="register" onClick={() => { handleAccept(); navigate("/register"); }}>
          Register
        </button>
        <button className="accept" onClick={handleAccept}>
          Got it
        </button>
      </div>
    </div>
  );
}
