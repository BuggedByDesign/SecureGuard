import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

function VerifyEmail() {
  const [status, setStatus] = useState("Verifying your email...");
  const navigate = useNavigate();

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const token = params.get("token");

    if (!token) {
      setStatus("❌ Verification token is missing.");
      return;
    }

    fetch(`http://localhost:5000/api/verify-email?token=${token}`)
      .then((res) => {
        if (!res.ok) throw new Error("Invalid or expired verification token.");
        return res.text();
      })
      .then((msg) => {
        setStatus(msg);
        setTimeout(() => navigate("/login"), 4000); // Redirect after 4 seconds
      })
      .catch((err) => {
        console.error(err);
        setStatus("❌ The verification link is invalid or has expired.");
      });
  }, [navigate]);

  return (
    <div className="flex items-center justify-center min-h-screen bg-gradient-to-r from-indigo-600 via-purple-700 to-pink-600 px-4">
      <div className="bg-white bg-opacity-20 backdrop-blur-lg rounded-xl shadow-xl max-w-md w-full p-8 text-center text-white">
        <h1 className="text-3xl font-extrabold mb-6">Email Verification</h1>
        <p className="text-lg">{status}</p>

        {status.toLowerCase().includes("success") && (
          <p className="mt-6 text-sm opacity-80">
            You will be redirected to the login page shortly...
          </p>
        )}

        {status.toLowerCase().includes("error") && (
          <button
            onClick={() => navigate("/resend-verification")}
            className="mt-6 inline-block bg-white bg-opacity-30 hover:bg-opacity-50 text-white font-semibold px-5 py-2 rounded-lg transition"
          >
            Resend Verification Email
          </button>
        )}
      </div>
    </div>
  );
}

export default VerifyEmail;
